import sqlite3
import os
from datetime import datetime

def show_users():
    # Получаем путь к базе данных
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'database', 'bot.db')
    
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Получаем всех пользователей
        cursor.execute('''
            SELECT user_id, full_name, group_name, is_authorized, notifications_enabled
            FROM users
            ORDER BY full_name
        ''')
        users = cursor.fetchall()
        
        if not users:
            print("❌ В базе данных нет пользователей")
            return
        
        # Выводим информацию о пользователях
        print("\n📊 Информация о пользователях бота:")
        print("=" * 50)
        
        for user in users:
            user_id, full_name, group_name, is_authorized, notifications_enabled = user
            print(f"\n👤 ФИО: {full_name}")
            print(f"🆔 ID: {user_id}")
            print(f"👥 Группа: {group_name}")
            print(f"✅ Авторизован: {'Да' if is_authorized else 'Нет'}")
            print(f"🔔 Уведомления: {'Включены' if notifications_enabled else 'Отключены'}")
            
            # Получаем все задания пользователя
            # cursor.execute('''
            #     SELECT title, task_type, subject, deadline, description, priority, status, lab_status
            #     FROM tasks
            #     WHERE user_id = ?
            #     ORDER BY deadline ASC
            # ''', (user_id,))
            # tasks = cursor.fetchall()
            
            # if tasks:
            #     print("\n📝 Задания пользователя:")
            #     for task in tasks:
            #         title, task_type, subject, deadline, description, priority, status, lab_status = task
            #         print(f"\n  📌 Название: {title}")
            #         print(f"  📋 Тип: {task_type}")
            #         print(f"  📚 Предмет: {subject}")
            #         print(f"  ⏰ Дедлайн: {deadline}")
            #         print(f"  📝 Описание: {description or 'Нет описания'}")
            #         print(f"  ⚠️ Приоритет: {priority}")
            #         print(f"  📊 Статус: {status}")
            #         if task_type == "🔬 Лабораторная":
            #             print(f"  🔬 Статус лабораторной: {lab_status}")
            # else:
            #     print("\n📝 У пользователя нет заданий")
            
            print("-" * 50)
        
        print(f"\n📈 Всего пользователей: {len(users)}")
        
    except sqlite3.Error as e:
        print(f"❌ Ошибка при работе с базой данных: {e}")
    except Exception as e:
        print(f"❌ Произошла ошибка: {e}")
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    show_users() 