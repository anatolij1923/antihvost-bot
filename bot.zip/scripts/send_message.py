import os
from aiogram import Bot
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

async def send_message(user_id: int, message_text: str):
    try:
        # Инициализация бота
        bot = Bot(token=os.getenv("BOT_TOKEN"))
        
        # Отправка сообщения
        await bot.send_message(user_id, message_text)
        print(f"✅ Сообщение успешно отправлено пользователю {user_id}")
        
    except Exception as e:
        print(f"❌ Ошибка при отправке сообщения: {e}")
    finally:
        await bot.session.close()

if __name__ == "__main__":
    import asyncio
    
    try:
        user_id = int(input("Введите ID пользователя: "))
        message = input("Введите текст сообщения: ")
        
        # Отправляем сообщение
        asyncio.run(send_message(user_id, message))
        
    except ValueError:
        print("❌ Ошибка: ID пользователя должен быть числом") 