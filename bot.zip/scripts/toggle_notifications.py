import sqlite3
import os

def toggle_notifications(user_id: int):
    # Путь к базе данных
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                          'database', 'bot.db')
    
    try:
        # Подключаемся к базе данных
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Получаем текущее состояние
        cursor.execute('SELECT notifications_enabled FROM users WHERE user_id = ?', (user_id,))
        current_state = cursor.fetchone()
        
        if not current_state:
            print(f"❌ Пользователь с ID {user_id} не найден")
            return
        
        # Переключаем состояние
        new_state = not current_state[0]
        cursor.execute('''
            UPDATE users
            SET notifications_enabled = ?
            WHERE user_id = ?
        ''', (new_state, user_id))
        
        conn.commit()
        print(f"✅ Уведомления {'включены' if new_state else 'выключены'} для пользователя {user_id}")
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    try:
        user_id = int(input("Введите ID пользователя: "))
        toggle_notifications(user_id)
    except ValueError:
        print("❌ Ошибка: ID пользователя должен быть числом") 